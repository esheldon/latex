#!/bin/sh

#cp -vf concentration.eps                     submit/Sheldon.fig01.eps
#cp -vf photoz_stripe09_10_11_12_13_14_15.eps submit/Sheldon.fig02.eps
#cp -vf spec_source_aitoff2.eps               submit/Sheldon.fig03.eps
#cp -vf redshift_hist.eps                     submit/Sheldon.fig04.eps
#cp -vf absmag_hist.eps                       submit/Sheldon.fig05.eps
#cp -vf deltasig.eps                          submit/Sheldon.fig06.eps
#cp -vf corr_matrix_deltasig.eps              submit/Sheldon.fig07.eps
#cp -vf rand_and_ortho.eps                    submit/Sheldon.fig08.eps
#cp -vf cluster_corr.eps                      submit/Sheldon.fig09.eps
#cp -vf xi_all_fits.eps                       submit/Sheldon.fig10.eps
#cp -vf corr_matrix_xi.eps                    submit/Sheldon.fig11.eps
#cp -vf xi_all_idit_bias_inv.eps              submit/Sheldon.fig12.eps
#cp -vf xi_vlim3_idit_bias_inv.eps            submit/Sheldon.fig13.eps
#cp -vf deltasig_all_allband_bylum.eps        submit/Sheldon.fig14.eps
#cp -vf xi_all_allband_bylum.eps              submit/Sheldon.fig15.eps
#cp -vf eclass_gmr_hist.eps                   submit/Sheldon.fig16.eps
#cp -vf deltasig_xi_early_late.eps            submit/Sheldon.fig17.eps
#cp -vf deltasig_redthree_allband_bylum.eps   submit/Sheldon.fig18.eps
#cp -vf xi_redthree_allband_bylum.eps         submit/Sheldon.fig19.eps
#cp -vf vel_dis_hist.eps                      submit/Sheldon.fig20.eps
#cp -vf deltasig_xi_vdis.eps                  submit/Sheldon.fig21.eps

cp -vf concentration.eps                     astroph/
cp -vf photoz_stripe09_10_11_12_13_14_15.eps astroph/
cp -vf spec_source_aitoff2_color.eps         astroph/
cp -vf redshift_hist.eps                     astroph/
cp -vf absmag_hist_color.eps                 astroph/
cp -vf deltasig.eps                          astroph/
cp -vf corr_matrix_deltasig.eps              astroph/
cp -vf rand_and_ortho.eps                    astroph/
cp -vf cluster_corr.eps                      astroph/
cp -vf xi_all_fits.eps                       astroph/
cp -vf corr_matrix_xi.eps                    astroph/
cp -vf xi_all_idit_bias_inv.eps              astroph/
cp -vf xi_vlim3_idit_bias_inv.eps            astroph/
cp -vf deltasig_all_allband_bylum_color.eps  astroph/
cp -vf xi_all_allband_bylum_color.eps        astroph/
cp -vf eclass_gmr_hist.eps                   astroph/
cp -vf deltasig_xi_early_late_color.eps      astroph/
cp -vf deltasig_redthree_allband_bylum_color.eps   astroph/
cp -vf xi_redthree_allband_bylum_color.eps   astroph/
cp -vf vel_dis_hist.eps                      astroph/
cp -vf deltasig_xi_vdis_color.eps            astroph/


